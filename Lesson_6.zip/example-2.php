<?php
// Перезапрос
header('Refresh: 3; url=http://itstep.by');

echo "Waiting 3 seconds!";