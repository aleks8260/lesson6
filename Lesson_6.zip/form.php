<?php

$file = ($_FILES['avatar']);
$filetmp = ($_FILES['avatar']['tmp_name']);

$dir = 'uploaded';

if (!file_exists(($dir))) {
	mkdir($dir,0777);
}

$filename = $dir. "/". $file['name'];


?>;